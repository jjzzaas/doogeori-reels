# 클라우드 루틴 설정 — 복사해서 붙여넣기용

## 1) 환경(Environment)
- 이름: doogeori
- Network access: Trusted
- Setup script:
```
apt-get update && apt-get install -y ffmpeg fonts-noto-cjk
pip install pillow numpy scipy
```

## 2) 저장소
- 공개(Public) 저장소 `doogeori-reels` 에 이 폴더의 파일을 올린다.
- 루틴의 branch push 허용 켜기(영상 URL용 브랜치에 push해야 함).

## 3) 커넥터
Google Drive, Metricool Social Media Management

## 4) 시험 운전용 프롬프트 (1회, 직접 실행)
OPERATING_GUIDE.md를 읽고 오늘의 릴스를 제작하라. 단, **실제 게시는 절대 하지 말 것.**
1. Drive 사진 폴더에서 사진 4장을 받아 config.json을 만들고 ./build_reel.sh 로 영상 생성(가능 여부 보고).
2. 완성 mp4를 `reels` 브랜치에 push하고 raw.githubusercontent.com 주소를 확보.
3. Metricool createScheduledPost를 draft:true, autoPublish:false, 날짜 2026-12-31, 인스타+페이스북 릴스, videoCoverMilliseconds 2500 으로 호출해 URL이 받아들여지는지 확인.
4. getScheduledPosts로 media가 static.metricool.com 으로 바뀌었는지 확인.
5. 보고는 3줄만: 영상 제작 성공/실패 · 영상 URL 전달 성공/실패 · 남은 문제.
