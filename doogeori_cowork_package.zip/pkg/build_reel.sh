#!/usr/bin/env bash
# usage: ./build_reel.sh config.json   -> out_dir/reel.mp4 + out_dir/cover.jpg
set -e
CFG="$1"
OUT=$(python3 -c "import json,sys;print(json.load(open('$CFG',encoding='utf-8'))['out_dir'])")
mkdir -p "$OUT"
python3 render_reel.py "$CFG"
python3 make_music.py "$OUT/music.wav"
ffmpeg -y -loglevel error -i "$OUT/silent.mp4" -i "$OUT/music.wav" \
  -filter_complex "[1:a]loudnorm=I=-19:TP=-2:LRA=7[a]" -map 0:v -map "[a]" \
  -c:v copy -c:a aac -b:a 192k -shortest -movflags +faststart "$OUT/reel.mp4"
ffprobe -v error -show_entries format=duration:stream=width,height -of default=nw=1 "$OUT/reel.mp4"
