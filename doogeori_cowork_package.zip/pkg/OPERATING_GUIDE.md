# 두거리우신탕 오산점 SNS 자동화 — 운영 가이드 (Cowork용)

## 0. 목표
영상을 매일 올리는 것이 아니라, 보고 나서 먹고 싶어지는 광고를 올린다.
품질 미달이면 게시하지 않는다. 안 된 것을 된 것처럼 보고하지 않는다.

## 1. 고정 정보
- 매장: 두거리우신탕 오산점 / 경기도 오산시 청호로 23
- 영업 10:00–21:30, 라스트오더 21:00, 매주 월요일 휴무
- 인스타 @doogeori_osan / 페이스북 매장 페이지 ID 1380415315162891
- Metricool blogId(brand) 7776101, 시간대 Asia/Seoul
- 사진 폴더(Drive): https://drive.google.com/drive/folders/1ZliNI5Dj0LH8km9HiGgOkR_MW3MNMQ4x
- 운영: 화~일. 16:00 제작·검수, 17:00 게시. 월요일은 아무것도 만들지 않는다.
- 개인 페이스북 프로필에는 절대 게시하지 않는다.

## 2. 매일 순서
1. 오늘 날짜 확인(월요일이면 종료).
2. Metricool getScheduledPosts로 오늘 날짜 게시물 확인. 오늘 이미 게시/예약된 릴스가 있으면 만들지 않고 보고만 한다.
3. Drive 폴더에서 신규·미사용 사진 확인. 사진을 직접 보고 음식/매장/기타로 분류.
   사용 이력은 `used_photos.json`에 기록해 중복 사용을 피한다.
4. 사진 4장 선택(음식 중심). 관련 없는 사진으로 억지로 채우지 않는다. 4장이 안 되면 게시하지 않고 사유 보고.
5. 오산(경기 남부) 당일 실제 날씨를 기상청/뉴스로 검색해 확인한다. 확인 안 되면 날씨 문구를 쓰지 않는다.
6. config.json 작성(example_config.json 참고) → `./build_reel.sh config.json`
7. 검수(아래 §4). 대표 프레임을 뽑아 실제로 눈으로 본다. 불합격이면 수정 후 재렌더.
8. 게시(§5) → 인스타/페북 각각 공개 여부 확인.
9. 보고: "인스타그램 게시 완료 / 페이스북 게시 완료" 또는 "미완료 — 원인: ○○".

## 3. 디자인 (A/B/C 순환, 레이아웃 공통)
- A 두거리 일기 / B 오늘의 맛 / C 저녁의 온도 (render_reel.py의 `design` 값)
- 9:16, 1080×1920, 15초, 4장면.
- 상하단은 **밝은 크림색 고정**, 중앙 사진만 움직인다. (어두운 상하단 금지 — 점주 피드백)
- **문구는 화면 중앙**. 사진은 살짝 어둡게 가라앉히고 문구가 메인. (사진 화질이 약해서)
- 정적이지 않게: 사진 확대·이동 크게, 장면은 옆으로 밀려 전환, 문구는 한 줄씩 올라옴.
- 글씨: 세리프 보통/아주 굵게 섞기, 핵심 단어는 금빛 강조 + 밑줄 애니메이션. 단조로운 단일 서체 금지.
  (손글씨 폰트를 점주가 제공하면 `NotoSerifCJK` 대신 교체)
- 문구는 매일 새로 쓴다. 이전 게시물과 같은 문장·비슷한 표현 금지.
- 이전 날 문구 목록은 `used_copy.json`에 저장해 비교한다.

## 4. 게시 전 검수 체크리스트
음식이 맛있어 보이는가 / 움직임 자연스러운가 / 글씨 가독성 / 상하단 고정 / 날씨 문구가 실제와 일치 /
메뉴명·정보가 사실인가(확인 안 된 메뉴명은 쓰지 않는다) / 검은 화면 없음 / 음량 적절(-19 LUFS 전후) /
커버 정상 / 이전 콘텐츠와 비슷하지 않은가 / 음악 저작권 문제 없음(make_music.py 직접 합성곡만 사용).
없는 음식·김·양 조작 금지, 자연스러운 색보정만.

## 5. 게시 (Metricool createScheduledPost)
- providers: instagram + facebook
- instagramData: {"type":"REEL","showReelOnFeed":true}
- facebookData: {"type":"REEL"}
- **videoCoverMilliseconds: 2500** (점주 요청: 커버는 2~3초 지점, 검은 화면 금지)
- publicationDate: {"dateTime":"YYYY-MM-DDTHH:mm:ss","timezone":"Asia/Seoul"}
- autoPublish: true
- 캡션 형식:
  > (오늘 날씨에 맞춘 한두 문장)
  >
  > 📍 두거리우신탕 오산점 · 경기도 오산시 청호로 23
  > 🕙 10:00–21:30 (라스트오더 21:00) · 매주 월요일 휴무
  >
  > #두거리우신탕 #두거리우신탕오산점 #오산맛집 #오산저녁 #뜨끈한국물
  내부 작업 메모(렌더링·검수 내용)는 절대 넣지 않는다.
- 예약 성공 ≠ 공개 성공. getScheduledPosts에서 각 플랫폼 status가 PUBLISHED이고 publicUrl이 있는지 확인.
  실패한 플랫폼만 재시도, 중복 게시 금지.

## 6. 첫 실행 때 반드시 검증할 것 (모르는 부분)
1. Cowork 컴퓨터에 ffmpeg, python3, Pillow, numpy, scipy, Noto CJK 폰트가 있는지. 없으면 설치 가능한지.
2. **영상 파일을 Metricool에 넣는 방법 — 2026-11-05 Claude 채팅 환경 검증 결과**
   - 검증됨(성공): createScheduledPost의 `media`에 공개 mp4 URL을 주면 등록된다. `videoCoverMilliseconds`도 허용된다.
   - 검증됨(성공): `mediaFiles` 파라미터는 Claude 환경에서도 `download_url`을 media에 그대로 붙여 준다.
     즉 "파일 업로드 기능"이 아니라 **URL 전달 통로**일 뿐이다. 필요한 것은 오직 "Metricool이 받아갈 수 있는 공개 mp4 URL".
   - 검증됨(실패): Google Drive 일반 보기 링크(`/view?usp=drivesdk`)는 "Failed to normalize media"로 거부됨.
     (Metricool 계정에 Drive 연동이 안 돼 있을 가능성 — Metricool 설정에서 Drive 연동 후 재시험 필요)
   - 검증됨(불가): Claude 채팅 샌드박스는 외부 네트워크 차단 + 업로드 도구 없음 + Drive 업로드 도구는 base64를 직접 써야 해서 9MB는 불가.
   - 표준 절차(미검증, 네트워크가 되는 환경 = Claude Code 클라우드 루틴 / Cowork 에서만 가능):
     1) 완성 mp4를 공개 URL로 올린다. 후보: (a) 루틴에 연결된 GitHub 저장소의 별도 브랜치/릴리스에 push → raw/asset URL
        (b) Drive API 또는 다른 파일 호스팅(자격증명 필요).
     2) 그 URL을 `media`(또는 `mediaFiles[].download_url`)로 Metricool에 전달.
     3) getScheduledPosts로 media가 `static.metricool.com/...`로 바뀌었는지, status PUBLISHED인지 확인.
     먼저 `draft:true`, 먼 미래 날짜로 URL 수용 여부만 시험하고, 실제 게시 전에는 점주 승인을 받는다.
     시험용 초안은 Metricool 앱에서 직접 삭제해야 한다(도구에 삭제 기능 없음).
   - 위가 모두 실패하면 자동 게시를 중단하고 완성 파일 위치와 함께 "미완료 — 원인: 파일 전달 불가"로 보고한다.
3. 예약 작업은 PC가 켜져 있고 Claude 데스크톱 앱이 열려 있어야 실행된다 — 15:50에 가능한지 점주와 확인.
4. 30편 게시 후 getAnalyticsDataByMetrics로 성과 분석(조회·도달·저장·공유 등 실제 수집되는 지표만).

## 7. 점주 승인이 필요한 것
디자인 대폭 변경, 계정/권한 변경, 추가 비용, 새 외부 서비스. 일상 게시에는 재승인을 요구하지 않는다.
