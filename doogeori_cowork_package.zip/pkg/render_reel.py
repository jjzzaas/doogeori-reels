import subprocess, math, json, sys, os
import numpy as np
from PIL import Image, ImageDraw, ImageFont, ImageEnhance, ImageOps, ImageFilter

W, H = 1080, 1920
TOP_H, BOT_Y = 270, 1610
CW, CH = W, BOT_Y - TOP_H
FPS, DUR = 30, 15.0

BAND = (252, 236, 208)       # warm cream
INK = (62, 38, 22)           # deep warm brown (text on bands)
MUTED = (140, 103, 72)
ACC = (200, 84, 40)          # terracotta
CREAM = (255, 244, 224)      # text on photo
GOLD = (255, 190, 92)        # accent on photo
DIM = (40, 22, 10)

NOTO = "/usr/share/fonts/opentype/noto/"
def F(name, size): return ImageFont.truetype(NOTO + name, size, index=1)
SERIF_BLACK, SERIF_B, SERIF_M = "NotoSerifCJK-Black.ttc", "NotoSerifCJK-Bold.ttc", "NotoSerifCJK-Medium.ttc"
SANS_M, SANS_B = "NotoSansCJK-Medium.ttc", "NotoSansCJK-Bold.ttc"

def tw(d, s, f, tr=0): return sum(d.textlength(c, font=f) for c in s) + tr * max(len(s) - 1, 0)
def dtext(d, x, y, s, f, fill, tr=0):
    for c in s:
        d.text((x, y), c, font=f, fill=fill); x += d.textlength(c, font=f) + tr
    return x
def dcenter(d, y, s, f, fill, tr=0, cx=W // 2):
    dtext(d, cx - tw(d, s, f, tr) / 2, y, s, f, fill, tr)

# ---------------- config ----------------
CFG = json.load(open(sys.argv[1], encoding="utf-8"))
PHOTO_DIR = CFG.get("photo_dir", ".")
OUT_DIR = CFG.get("out_dir", ".")
os.makedirs(OUT_DIR, exist_ok=True)
THEMES = {  # A/B/C brand designs share one layout; only the title + accent change
    "A": dict(title="두거리 일기", band=(250, 238, 220), acc=(176, 96, 60)),
    "B": dict(title="오늘의 맛", band=(252, 236, 208), acc=(200, 84, 40)),
    "C": dict(title="저녁의 온도", band=(244, 232, 222), acc=(150, 80, 70)),
}
TH = THEMES[CFG.get("design", "B")]
BAND = TH["band"]; ACC = TH["acc"]
DATE_LABEL = CFG["date_label"]            # e.g. "2026. 11. 05  목요일"

# ---------------- fixed bright frame ----------------
def band_layer(active=0, n=4):
    im = Image.new("RGB", (W, H), BAND)
    d = ImageDraw.Draw(im)
    dcenter(d, 92, DATE_LABEL, F(SANS_M, 32), MUTED, tr=5)
    dcenter(d, 130, TH["title"], F(SERIF_BLACK, 76), INK, tr=6)
    pts = [(W // 2 - 60 + i, 236 + 4 * math.sin(i / 9.0)) for i in range(0, 121)]
    d.line(pts, fill=ACC, width=5, joint="curve")
    dcenter(d, BOT_Y + 56, "두거리우신탕 오산점", F(SERIF_BLACK, 62), INK, tr=3)
    dcenter(d, BOT_Y + 142, "경기도 오산시 청호로 23", F(SANS_M, 32), MUTED, tr=2)
    gap = 34
    x0 = W // 2 - gap * (n - 1) / 2
    for i in range(n):
        r = 8 if i != active else 11
        c = ACC if i == active else (222, 196, 160)
        d.ellipse([x0 + i * gap - r, BOT_Y + 232 - r, x0 + i * gap + r, BOT_Y + 232 + r], fill=c)
    return im
N_ = "n"; A_ = "a"
# ---------------- photos ----------------
def prep(path, warm=1.0, bright=1.0, contrast=1.0, color=1.0, sharp=1.0):
    im = ImageOps.exif_transpose(Image.open(path)).convert("RGB")
    im = im.resize((2160, int(2160 * im.height / im.width)), Image.LANCZOS)
    if warm != 1.0:
        r, g, b = im.split()
        k = 0.035 * (warm - 1) * 10
        r = r.point(lambda v: min(255, int(v * (1 + k)))); b = b.point(lambda v: int(v * (1 - k)))
        im = Image.merge("RGB", (r, g, b))
    for E, v in ((ImageEnhance.Brightness, bright), (ImageEnhance.Contrast, contrast), (ImageEnhance.Color, color), (ImageEnhance.Sharpness, sharp)):
        im = E(im).enhance(v)
    return im

def _segs(lst): return [(t, k) for t, k in lst]
scenes = []
for s in CFG["scenes"]:
    g = s.get("grade", {})
    scenes.append(dict(
        img=prep(os.path.join(PHOTO_DIR, s["photo"]), g.get("warm", 1.1), g.get("bright", 1.05), g.get("contrast", 1.06), g.get("color", 1.08), g.get("sharp", 1.2)),
        c0=tuple(s["c0"]), c1=tuple(s["c1"]), z0=s["z0"], z1=s["z1"], dim=s.get("dim", 0.52),
        cap=s["cap"], l1=_segs(s["l1"]), l2=_segs(s["l2"])))
assert len(scenes) == 4, "this layout expects exactly 4 scenes"
FRAMES = [band_layer(i) for i in range(4)]
STARTS = [0.0, 3.6, 7.2, 10.8]; SCENE_LEN = 4.2; TR = 0.55

def ease(t): t = max(0., min(1., t)); return t * t * (3 - 2 * t)
def eout(t): t = max(0., min(1., t)); return 1 - (1 - t) ** 3

def photo(sc, lt):
    p = ease(lt / SCENE_LEN)
    z = sc["z0"] + (sc["z1"] - sc["z0"]) * p
    cx = sc["c0"][0] + (sc["c1"][0] - sc["c0"][0]) * p
    cy = sc["c0"][1] + (sc["c1"][1] - sc["c0"][1]) * p
    iw, ih = sc["img"].size
    bw = iw / z; bh = bw * CH / CW
    if bh > ih: bh = ih; bw = bh * CW / CH
    x0 = min(max(cx * iw - bw / 2, 0), iw - bw); y0 = min(max(cy * ih - bh / 2, 0), ih - bh)
    return sc["img"].resize((CW, CH), Image.LANCZOS, box=(x0, y0, x0 + bw, y0 + bh))

dim_img = Image.new("RGB", (CW, CH), DIM)

def segs_width(d, segs, f1, f2, tr):
    return sum(tw(d, s, f2 if k == A_ else f1, tr) for s, k in segs) + tr * (len(segs) - 1)

def draw_line(lay, y, segs, size, alpha, rise, underline_p, cy_center=CW // 2):
    d = ImageDraw.Draw(lay)
    s = size
    while True:
        fN, fA = F(SERIF_B, s), F(SERIF_BLACK, s)
        total = segs_width(d, segs, fN, fA, 2)
        if total <= CW - 130 or s < 50: break
        s -= 3
    x = CW / 2 - total / 2; y = y + rise
    a = int(255 * alpha)
    for t, k in segs:
        f = fA if k == A_ else fN
        col = (GOLD if k == A_ else CREAM) + (a,)
        x_end = dtext(d, x, y, t, f, col, 2)
        if k == A_ and underline_p > 0:
            w = x_end - x - 2; yy = y + s * 1.28
            n = int(w * underline_p)
            pts = [(x + i, yy + 5 * math.sin(i / 11.0)) for i in range(0, max(n, 2))]
            d.line(pts, fill=GOLD + (int(a * 0.95),), width=7, joint="curve")
        x = x_end + 2

def scene_center(sc, lt, idx):
    cw = photo(sc, lt)
    dim_a = sc.get('dim',0.52) * ease((lt - 0.55) / 0.7)
    if idx == 0 and False: dim_a = 0
    out_fade = 1.0 if idx == 3 else 1 - ease((lt - 3.35) / 0.3)
    dim_eff = dim_a * (0.35 + 0.65 * out_fade)
    cw = Image.blend(cw, dim_img, dim_eff)
    lay = Image.new("RGBA", (CW, CH), (0, 0, 0, 0))
    cy = CH // 2
    # caption
    pc = ease((lt - 0.85) / 0.4) * out_fade
    if pc > 0.01:
        d = ImageDraw.Draw(lay); f = F(SANS_B, 34)
        w = tw(d, sc["cap"], f, 5)
        dtext(d, CW / 2 - w / 2, cy - 196 + (1 - pc) * 24, sc["cap"], f, GOLD + (int(255 * pc),), 5)
    p1 = ease((lt - 1.05) / 0.55) * out_fade
    p2 = ease((lt - 1.40) / 0.55) * out_fade
    pu = ease((lt - 1.9) / 0.6)
    if p1 > 0.01: draw_line(lay, cy - 130, sc["l1"], 90, p1, (1 - p1) * 46, 0)
    if p2 > 0.01: draw_line(lay, cy - 10, sc["l2"], 96, p2, (1 - p2) * 46, pu * out_fade)
    # shadow
    sh = lay.split()[3].filter(ImageFilter.GaussianBlur(10)).point(lambda v: int(v * 0.65))
    cw = cw.convert("RGBA")
    cw.paste(Image.new("RGBA", (CW, CH), (10, 5, 0, 255)), (0, 0), sh)
    cw.alpha_composite(lay)
    return cw.convert("RGB")

def compose(t):
    # find current & previous scene for push transition
    cur = max(i for i in range(4) if t >= STARTS[i])
    lt = t - STARTS[cur]
    frame_idx = cur
    cwin = scene_center(scenes[cur], lt, cur)
    if cur > 0 and lt < TR:
        prev = scene_center(scenes[cur - 1], t - STARTS[cur - 1], cur - 1)
        p = eout(lt / TR)
        canvas = Image.new("RGB", (CW, CH), DIM)
        canvas.paste(prev, (int(-p * CW * 0.30), 0))
        canvas.paste(cwin, (int((1 - p) * CW), 0))
        cwin = canvas
        frame_idx = cur if p > 0.5 else cur - 1
    out = FRAMES[frame_idx].copy()
    out.paste(cwin, (0, TOP_H))
    return out

def render_video(path=None):
    path = path or os.path.join(OUT_DIR, "silent.mp4")
    cmd = ["ffmpeg", "-y", "-loglevel", "error", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{W}x{H}",
           "-r", str(FPS), "-i", "-", "-c:v", "libx264", "-preset", "slow", "-crf", "16", "-pix_fmt", "yuv420p",
           "-movflags", "+faststart", path]
    pr = subprocess.Popen(cmd, stdin=subprocess.PIPE)
    for k in range(int(DUR * FPS)):
        pr.stdin.write(compose(min(k / FPS, DUR - 0.001)).tobytes())
    pr.stdin.close(); pr.wait()

def make_cover(path=None):
    path = path or os.path.join(OUT_DIR, "cover.jpg")
    sc = scenes[0]
    cw = photo(dict(sc, z0=1.0, z1=1.0, c0=(0.5, 0.40), c1=(0.5, 0.40)), 0)
    cw = Image.blend(cw, dim_img, 0.50)
    lay = Image.new("RGBA", (CW, CH), (0, 0, 0, 0)); cy = CH // 2
    d = ImageDraw.Draw(lay); f = F(SANS_B, 36)
    cap = "오늘의 날씨 · 흐리고 쌀쌀"
    dtext(d, CW / 2 - tw(d, cap, f, 5) / 2, cy - 230, cap, f, GOLD + (255,), 5)
    draw_line(lay, cy - 165, sc["l1"], 104, 1, 0, 0)
    draw_line(lay, cy - 20, sc["l2"], 112, 1, 0, 1)
    sh = lay.split()[3].filter(ImageFilter.GaussianBlur(10)).point(lambda v: int(v * 0.65))
    cw = cw.convert("RGBA"); cw.paste(Image.new("RGBA", (CW, CH), (10, 5, 0, 255)), (0, 0), sh)
    cw.alpha_composite(lay)
    out = FRAMES[0].copy(); out.paste(cw.convert("RGB"), (0, TOP_H)); out.save(path, quality=95)

if __name__ == "__main__":
    make_cover(); render_video(); print("done")
